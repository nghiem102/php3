<?php
require_once __DIR__ . "/../vendor/autoload.php";

use App\Controllers\Controller;
use App\Controllers\HomeController;
use App\Controllers\ProductController;
use App\Controllers\CategoryController;
use App\Router;

Router::get('/', [HomeController::class, 'index']);
//ADMIN
Router::get('/admin', [HomeController::class, 'admin']);
//Products 
Router::get('/admin/rooms', [ProductController::class, 'index']);
Router::get('/admin/rooms/add', [ProductController::class, 'add']);
Router::post('/admin/rooms/add', [ProductController::class, 'save']);
Router::get('/admin/rooms/edit', [ProductController::class, 'edit']);
Router::post('/admin/rooms/edit', [ProductController::class, 'update']);
Router::get('/admin/rooms/del', [ProductController::class, 'del']);
//Category
Router::get('/admin/type', [CategoryController::class, 'index']);
Router::get('/admin/type/add', [CategoryController::class, 'add']);
Router::post('/admin/type/add', [CategoryController::class, 'save']);
Router::get('/admin/type/edit', [CategoryController::class, 'edit']);
Router::post('/admin/type/edit', [CategoryController::class, 'update']);
Router::get('/admin/type/del', [CategoryController::class, 'del']);
Router::run();
