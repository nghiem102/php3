<?php include_once '../app/views/layout/layoutadmin.php'?>
<main>
    <span class="name_menu">Phòng</span>
    <a class="add-user" href="/admin/rooms/add">Thêm mới</a>
    <table>
    <thead>
        <tr>
        <th>ID</th>
        <th>Tên sp</th>
        <th>Giá</th>
        <th>Số phòng</th>
        <th>Intro</th>
        <th>Mô tả</th>
        <th>Ảnh</th>
        <th>Loại</th>
        <th colspan="2">Hành động</th>
        </tr></thead>
        <tbody>
   <?php foreach ($products as $a):?> 
    <tr>
    <td><?= $a->id ?></td>
    <td><?= $a->name ?></td>
    <td><?= $a->price ?></td>
    <td><?= $a->quantity ?></td>
    <td><?= $a->intro ?></td>
    <td><?= $a->description ?></td>
    <td><img src="/images/<?= $a->image?>" alt=""></td>
    <td><?php for ($i=0; $i < count($categories); $i++) { 
        if ($categories[$i]->id==$a->cate_id){
            echo $categories[$i]->type_name;
        }}
 ?></td>
    <td><a href="/admin/rooms/edit?id=<?= $a->id ?>"><i class='bx icon-table bx-edit-alt' ></i></a></td>
    <td><a href="/admin/rooms/del?id=<?= $a->id ?>"><i class='bx icon-table bx-trash-alt' ></i></a></td></tr>
    <?php endforeach;?>
        </tbody>
    </table>
</main>
</body>

</html>