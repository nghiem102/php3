<?php

namespace App\Models;

class CategoryModel extends BaseModel
{
    protected $tableName = 'types';
}
