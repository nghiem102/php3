<?php

namespace App\Models;

class ProductModel extends BaseModel
{
    protected $tableName = "rooms";
}
