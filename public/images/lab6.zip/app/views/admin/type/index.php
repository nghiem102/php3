<?php include_once '../app/views/layout/layoutadmin.php'?>
<main>
    <span class="name_menu">Loại phòng</span>
    <a class="add-user" href="/admin/type/add">Thêm mới</a>
    <table>
    <thead>
        <tr>
        <th>ID</th>
        <th>Tên loại</th>
        <th colspan="2">Hành động</th>
        </tr></thead>
        <tbody>
   <?php foreach ($category as $a):?> 
    <tr>
    <td><?= $a->id ?></td>
    <td><?= $a->type_name ?></td>
    <td><a href="/admin/type/edit?id=<?= $a->id ?>"><i class='bx bx-edit-alt' ></i></a></td>
    <td><a href="/admin/type/del?id=<?= $a->id ?>"><i class='bx bx-trash-alt'></i></a></td></tr>
    <?php endforeach;?>
        </tbody>
    </table>
</main>
</body>

</html>