<?php

namespace App\Controllers;

use App\Models\CategoryModel;

class CategoryController extends Controller
{   
    public function index(){
        $category = CategoryModel::all();
        
        return $this->view('admin/type.index', ['category' => $category]);
    }
    public function add()
    {
        return $this->view('admin/type.add');
    }

    //Thêm mới dữ liệu
    public function save()
    {
        $request = [];
        $request = [
            'type_name'=>$_POST['type_name']
        ];
        // Validate
        $errors=[];

        if ($request['type_name']=='') {
            $errors['type_name']="Bạn cần nhập tên loại";
            return $this->view('admin/type.add', [ 'errors'=>$errors,'request'=>$request]);
        }
        if (!$errors) {
        $category = new CategoryModel;
        $category->insert($request);
        header("location: /admin/type");
        exit();
        }
        
        
    }
    public function del(){
        $id=$_GET['id'];
        $product = new CategoryModel;
        $product->destroy($id);
        header("location: /admin/type");die;
    }
    public function edit(){
        $id=$_GET['id'];
        $category= CategoryModel::find($id);
        return $this->view('admin/type.edit', ['category' => $category]);
        
    }
    public function update(){
        $id=$_GET['id'];
        $request = $_POST;

        // Validate
        $errors=[];

        if ($request['type_name']=='') {
            $errors['type_name']="Bạn cần nhập tên phòng";  
        }else{
            $errors['type_name']="";
        }
        if($errors['type_name']==""){
        $request['id'] = $id;
        $products = new CategoryModel;
        $products->update($request);
        header("location: /admin/type");
        }
        return $this->view('admin/type.edit', ['request'=>$request,'errors'=>$errors,'id'=>$id]);
    }
}
