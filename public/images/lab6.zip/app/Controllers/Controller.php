<?php

namespace App\Controllers;

class Controller
{
    public function view($path, $data = [])
    {   $admin_url='/var/www/html/web3014.01/app/views/admin';
        extract($data);
        $path = str_replace('.', '/', $path);
        include_once __DIR__ . "/../views/" . $path . ".php";
    }
}
