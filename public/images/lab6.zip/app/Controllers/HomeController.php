<?php

namespace App\Controllers;

use App\Models\ProductModel;
use App\Models\CategoryModel;

class HomeController extends Controller
{
    public function index()
    {
        
    }
    public function show()
    {
        $id = $_GET['id'] ?? null;
        if (!$id) {
            header("location: /");
            die;
        }
        $product = ProductModel::find($id);
        if (!$product) {
            header("location: /");
            die;
        }
        return $this->view('home.show', ['product' => $product]);
    }
}
