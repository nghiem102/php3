<?php
include_once '../app/views/layout/layoutadmin.php';
if(isset($request)){
extract($request);}
?>
<main>
<span class="name_menu">Sửa loại phòng <?$id?></span>
    <form action="/admin/type/edit?id=<?=$category->id?>" method="post" enctype="multipart/form-data">
<span class="link_name" style="color: #000;font-weight: 600;">Tên loại phòng</span>
<input type="text" name="type_name" value="<?=$category->type_name?><?=$type_name?>" placeholder="Nhập tên loại">
<span><?php echo $errors['type_name'] ?></span><br>
<button type="submit">Sửa</button>
</form>
</main>
</body>

</html>  