
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <link id="switch-css" rel="stylesheet" href="/css//style.css">
    <script src="./public/js/dark.js"></script>
    <link rel="stylesheet" href="/css/list-user.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <div class="sidebar dong">
        <div class="logo-details">
            <i class='bx bx-message-square-dots'></i>
            <span class="logo_name">ADMIN</span>
        </div>
        <ul class="nav-links">
        <li>
                <a href="/">
                <i class='bx bx-home'></i>
                    <span class="link_name">Trang chủ</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="#">Trang chủ</a></li>
                </ul>
            </li>
            <li>
                <a href="/admin">
                    <i class='bx bx-grid-alt'></i>
                    <span class="link_name">Trang chủ admin</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="/admin">Trang chủ admin</a></li>
                </ul>
            </li>
            <li>
                <div class="iocn-link">
                    <a href="#">
                        <i class='bx bx-collection'></i>
                        <span class="link_name">Loại phòng</span>
                    </a>
                    <i class='bx bxs-chevron-down arrow'></i>
                </div>
                <ul class="sub-menu">
                    <li><a class="link_name" href="#">Loại phòng</a></li>
                    <li><a href="/admin/type">Danh sách loại phòng</a></li>
                    <li><a href="/admin/type/add">Thêm loại phòng</a></li>
                </ul>
            </li>
            <li>
                <div class="iocn-link">
                    <a href="#">
                        <i class='bx bx-collection'></i>
                        <span class="link_name">Phòng</span>
                    </a>
                    <i class='bx bxs-chevron-down arrow'></i>
                </div>
                <ul class="sub-menu">
                    <li><a class="link_name" href="#">Phòng</a></li>
                    <li><a href="/admin/rooms">Danh sách Phòng</a></li>
                    <li><a href="/admin/rooms/add">Thêm Phòng</a></li>
                </ul>
            </li>
        </ul>
    </div>
    <section class="home-section">
        <div class="home-content">
            <i class='bx bx-menu'></i>
            <span class="text">Menu</span>
        </div>
    </section>
    <script src="/js/button-menu.js"></script>