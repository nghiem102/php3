<?php

namespace App\Controllers;

use App\Models\CategoryModel;
use App\Models\ProductModel;

class ProductController extends Controller
{   
    public function index(){
        $categories = CategoryModel::all();
        $products = ProductModel::all();
        
        return $this->view('admin/rooms.index', ['products' => $products,'categories' => $categories]);
    }
    public function add()
    {

        $categories = CategoryModel::all();
        return $this->view('admin/rooms.add', ['categories' => $categories]);
    }

    //Thêm mới dữ liệu
    public function save()
    {
        $request = $_POST;

        //Validate
        $errors=[];
        if ($request['name']=='') {
            $errors['name']="Bạn cần nhập tên phòng";
        }else{
            $errors['name']="";
        }
        if ($request['cate_id']=='0') {
            $errors['cate_id']="Bạn cần chọn loại";
        }else{
            $errors['cate_id']="";
        }
        if ($request['price']<='0') {
            $errors['price']="Bạn cần nhập giá > 0";
        }else{
            $errors['price']="";
        }
        if ($request['quantity']<='0') {
            $errors['quantity']="Bạn cần nhập number > 0";
        }else{
            $errors['quantity']="";
        }
        if ($request['intro']=='') {
            $errors['intro']="Bạn cần nhập intro";
        }else{
            $errors['intro']="";
        }
        if (strlen($request['description'])>'2000') {
            $errors['description']="Bạn cần nhập mô tả không quá 2000 ký tự";
        }else{
            $errors['description']="";
        }
        $file = $_FILES['image'];
        if($file['size'] == 0){
            $errors['image']='Bạn phải chọn file ảnh';
        }
        else if ($file['size'] > 0) {
            $image = $file['name'];
            $ext = strtolower(pathinfo($image,PATHINFO_EXTENSION));
            if($ext!='jpg'&&$ext!='jpeg'&&$ext!='png'&&$ext!='webp'&&$ext!='gif'){
                $errors['image']='Bạn cần chọn file đúng định dạng';
            }
        }else{
            $errors['image']='';
        }
        if ($errors['name']==""&&$errors['cate_id']==""&&$errors['price']==""&&$errors['quantity']==""&&$errors['intro']==""&&$errors['image']==""&&$errors['description']=="") {
        $request['image'] = $image;
        $products = new ProductModel;
        $products->insert($request);

        //upload ảnh
        $files = $_FILES['image'];
        if ($file['size'] > 0) {
            $image = $files['name'];
            move_uploaded_file($files['tmp_name'], '/images/' . $image);
            move_uploaded_file($_FILES["file"], 'p/file.jpg');
        }

        header("location: /admin/rooms");
        exit();
        }
        $categories = CategoryModel::all();
        return $this->view('admin/rooms.add', ['request'=>$request,'categories' => $categories,'errors'=>$errors]);
        
    }
    public function del(){
        $id=$_GET['id'];
        $product = new ProductModel;
        
        $product->destroy($id);
        header("location: /");die;
    }
    public function edit(){
        $id=$_GET['id'];
        $product= ProductModel::find($id);
        $categories = CategoryModel::all();
            
        return $this->view('admin/rooms.edit', ['product'=>$product,'categories' => $categories]);
        
    }
    public function update(){
        $id=$_GET['id'];
        $request = $_POST;

        //Validate
        $errors=[];
        if ($request['name']=='') {
            $errors['name']="Bạn cần nhập tên";
        }else{
            $errors['name']="";
        }
        if ($request['cate_id']=='0') {
            $errors['cate_id']="Bạn cần chọn loại hàng";
        }else{
            $errors['cate_id']="";
        }
        if ($request['price']<='0') {
            $errors['price']="Bạn cần nhập giá > 0";
        }else{
            $errors['price']="";
        }
        if ($request['quantity']<='0') {
            $errors['quantity']="Bạn cần nhập số lượng > 0";
        }else{
            $errors['quantity']="";
        }
        if ($request['intro']=='') {
            $errors['intro']="Bạn cần nhập intro";
        }else{
            $errors['intro']="";
        }
        if (strlen($request['description'])>'2000') {
            $errors['description']="Bạn cần nhập mô tả không quá 2000 ký tự";
        }else{
            $errors['description']="";
        }
        $file = $_FILES['image'];
        if ($file['size'] > 0) {
            $image = $file['name'];
            $ext = strtolower(pathinfo($image,PATHINFO_EXTENSION));
            if($ext!='jpg'&&$ext!='jpeg'&&$ext!='png'&&$ext!='webp'&&$ext!='gif'){
                $errors['image']='Bạn cần chọn file đúng định dạng';
            }
        }else{
            $errors['image']='';
        }
        if ($errors['name']==""&&$errors['cate_id']==""&&$errors['price']==""&&$errors['quantity']==""&&$errors['intro']==""&&$errors['image']==""&&$errors['description']=="") {            if(!empty($file['name']))
        {
        $request['id'] = $id;
        $request['image'] = $image;
        $products = new ProductModel;
        $products->update($request);

        //upload ảnh
        if ($file['size'] > 0) {
            move_uploaded_file($file['tmp_name'], 'images/' . $image);
        }

        header("location: /admin/rooms");
        }else if (empty($file['name'])) {
            $request['id'] = $id;
            unset($request['image']);
            $products = new ProductModel;
            $products->update($request);
            header("location: /admin/rooms");
        }}
        
        $categories = CategoryModel::all();
        return $this->view('admin/rooms.edit', ['request'=>$request,'categories' => $categories,'errors'=>$errors,'id'=>$id]);
    }
}
