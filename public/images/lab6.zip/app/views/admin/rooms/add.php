<?php
include_once '../app/views/layout/layoutadmin.php';
if(isset($request)){
extract($request);}
?>
<main>
<span class="name_menu">Thêm phòng</span>
<form action="/admin/rooms/add" method="post" enctype="multipart/form-data">
<span class="link_name" style="color: #000;font-weight: 600;">Tên phòng</span>
<input type="text" name="name" value="<?=$name?>" placeholder="Nhập tên phòng">
<span><?= $errors['name'] ?></span><br>
<span class="link_name" style="color: #000;font-weight: 600;">Loại phòng</span>
<select name="cate_id">
            <option value="0">Chọn danh mục</option>
            <?php foreach ($categories as $cate) : ?>
                <option value="<?= $cate->id ?>" <?= isset($cate_id)?($cate_id==$cate->id)?'selected':'':'' ?>>
                    <?= $cate->type_name ?>
                </option>
            <?php endforeach ?>
        </select>
<span><?php echo $errors['cate_id'] ?></span><br>
<span class="link_name" style="color: #000;font-weight: 600;">Giá</span>
<input type="number" name="price" id="" value="<?=$price?>" placeholder="Nhập giá phòng">
<span><?php echo $errors['price'] ?></span><br>
<span class="link_name" style="color: #000;font-weight: 600;">Số phòng</span>
<input type="number" name="quantity" id="" value="<?=$quantity?>" placeholder="Nhập số lượng phòng">
<span><?php echo $errors['quantity'] ?></span><br>
<span class="link_name" style="color: #000;font-weight: 600;">Intro</span>
<input type="text" name="intro" id="" value="<?=$intro?>" placeholder="Nhập intro">
<span><?php echo $errors['intro'] ?></span><br>
<span class="link_name" style="color: #000;font-weight: 600;">Hình</span>
<input type="file" name="image" class='file' id="" placeholder="Chọn hình ảnh">
<span><?php echo $errors['image'] ?></span><br>
<span class="link_name" style="color: #000;font-weight: 600;">Mô tả</span>
<textarea name="description" cols="100" rows="5"><?=$description?></textarea>
<span><?php echo $errors['description'] ?></span><br>

<button type="submit">Thêm</button>
</form>
</main>
</body>

</html>  