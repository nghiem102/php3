<?php
include_once '../app/views/layout/layoutadmin.php';
if(isset($request)){
extract($request);}
?>
<main>
<span class="name_menu">Thêm loại hàng</span>
    <form action="/admin/type/add" method="post" enctype="multipart/form-data">
<span class="link_name" style="color: #000;font-weight: 600;">Tên loại phòng</span>
<input type="text" name="type_name" value="<?=$type_name?>" placeholder="Nhập tên loại phòng">
<span><?php echo $errors['type_name'] ?></span><br>
<button type="submit">Thêm</button>
</form>
</main>
</body>

</html>  